using YukkuriMovieMaker.Plugin;
using System.ComponentModel;

namespace PreviewLite;

public sealed class PreviewLitePlugin : IToolPlugin
{
    // Attach at plugin discovery, before preview calls can be JIT-inlined by YMM's worker.
    // No optimizations are enabled until the user opens the tool and explicitly selects ON.
    public PreviewLitePlugin() => PreviewRuntime.Prepare();
    public string Name => "PreviewLite：軽量プレビュー・動画参照（試作）";
    public Type ViewModelType => typeof(PreviewLiteViewModel);
    public Type ViewType => typeof(PreviewLiteView);
    public bool AllowMultipleInstances => false;
}

public sealed class PreviewLiteViewModel : ITimelineToolViewModel, INotifyPropertyChanged
{
    public TimelineToolInfo? TimelineInfo { get; private set; }
    public event PropertyChangedEventHandler? PropertyChanged;
    public void SetTimelineToolInfo(TimelineToolInfo info)
    {
        TimelineInfo = info;
        PropertyChanged?.Invoke(this, new(nameof(TimelineInfo)));
    }
}
