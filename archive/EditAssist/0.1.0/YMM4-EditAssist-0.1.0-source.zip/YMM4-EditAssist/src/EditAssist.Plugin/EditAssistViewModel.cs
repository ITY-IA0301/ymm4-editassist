using System.ComponentModel;
using EditAssist.Core;

namespace EditAssist.Plugin;

// YMM4 creates this through IToolPlugin. Avoid IO in the constructor.
public sealed class EditAssistViewModel : INotifyPropertyChanged
{
    private IReadOnlyList<MaterialEntry> results = Array.Empty<MaterialEntry>();
    private string status = "準備中…";
    public IReadOnlyList<MaterialEntry> Results
    {
        get => results;
        set { results = value; PropertyChanged?.Invoke(this, new(nameof(Results))); }
    }
    public string Status
    {
        get => status;
        set { status = value; PropertyChanged?.Invoke(this, new(nameof(Status))); }
    }
    public event PropertyChangedEventHandler? PropertyChanged;
}

