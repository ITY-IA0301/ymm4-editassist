using YukkuriMovieMaker.Plugin;

namespace EditAssist.Plugin;

public sealed class EditAssistToolPlugin : IToolPlugin
{
    public string Name => "EditAssist：素材とプレビュー診断";
    public Type ViewModelType => typeof(EditAssistViewModel);
    public Type ViewType => typeof(EditAssistView);
    public bool AllowMultipleInstances => false;
}

